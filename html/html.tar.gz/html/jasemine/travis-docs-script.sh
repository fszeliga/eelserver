git clone https://github.com/jasmine/jasmine.github.io.git

bundle exec rake jasmine:ci JASMINE_CONFIG_PATH=jasmine.github.io/2.0/spec/support/jasmine.yml
